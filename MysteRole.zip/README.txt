IMPORTANT : Gardez tous les fichers et dossiers ensemble.
R�pertoire complet : https://github.com/Quantum957114/MysteRole
------
- Remise : https://github.com/Quantum957114/MysteRole/raw/master/MysteRole.zip
------
SPACE est la touche d'action.
Utiliser les touches fl�ch�es pour progresser.