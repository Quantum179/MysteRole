IMPORTANT : Gardez tous les fichers et dossiers ensemble.
https://github.com/Quantum957114/MysteRole
SPACE est la touche d'action.
Utiliser les touches fl�ch�es pour progresser.