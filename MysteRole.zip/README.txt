IMPORTANT : Gardez tous les fichers et dossiers ensemble.
R�pertoire complet : https://github.com/Quantum957114/MysteRole
------
- Remise : https://github.com/Quantum957114/MysteRole/raw/master/MysteRole.zip
------
SPACE est la touche d'action.
Z est pour annul� un choix (utile en combat surtout).
Pr�s d'un PNJ, il faut faire ESCAPE pour lui parler.
L pour ouvrir le menu en jeu.
F12 pour ouvrir le menu de d�bogage
Utiliser les touches fl�ch�es (ou ASDW) pour progresser.